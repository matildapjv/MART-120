var x = 100;
var y = 100;
function setup()
{
    createCanvas(500, 600);
}

function draw()
{
    background(214,230,231);
    textSize(20);
    text("X: " + mouseX,100,200 );
    text("Y: " + mouseY,100,220 );
  
    fill(255,255,255)
    rect(0,460,500,150)
    stroke(255,255,255)
    strokeWeight(5)
    point(37,401)
    point(178,439)
    point(110,325)
    point(113,172)
    point(16,124)
    point(404,42)
    point(38,8)
  
  // back of hair
    stroke(90,44,7)
    fill(110,57,39)
    circle(200,222,40)
    circle(201,241,40)
    circle(219,245,40)
    circle(199,259,40)
    circle(295,224,40)
    circle(275,242,40)
    circle(270,261,40)
    circle(304,248,40)
    circle(274,280,40)
    circle(304,276,40)
    circle(323,279,40)
    circle(222,279,40)
    circle(189,283,40)
    stroke(0)
    fill(230,198,183)
    rect(239,233,15,17)
  
    //head
    strokeWeight(2)
    fill(230,198,183)
    circle (247,175,125)
    strokeWeight(0)
    fill(224,163,187)
    circle(210,205,20)
    circle(278,205,20)
  
    //eyes
    strokeWeight(4)
    stroke(0)
    fill(255,255,255)
    circle(215,175,32)
    circle(275,175,32)
    //iris
    strokeWeight(3)
    stroke(0)
    fill(129,207,255)
    circle(211,176,16)
    circle(271.5,176,16)
    stroke(230,198,183)
  //pupil
    strokeWeight(2)
    stroke(0)
    fill(0,0,0)
    circle(211,176,5)
    circle(271.5,176,5)
    
  //eyelids
    strokeWeight(0)
    fill(230,198,183)
    rect(199,156,32,14)
    rect(260,156,31,14)
    stroke(0)
    strokeWeight(3)
    fill(0,0,0)
    line(200,170,230,170)
    line(259,170,290,170)
  //
    
  //
    line(199,171,230,171)
    line(259,171,291,171)
  // lid line
    stroke(190,142,119)
    line(200,165,230,165)
    line(259,165,290,165)
  //brows
    strokeWeight(5.5)
    stroke(90,44,7)
    line(200,157,230,157)
    line(259,157,290,157)
  //lashes
    strokeWeight(3)
    stroke(0)
    line(200,180,196,184)
    line(201,187,199,189)
  //
    line(291,175,297,177)
    line(288,183,293,187)


    //nose -- bL,T,bR
    strokeWeight(2)
    stroke(122,60,22)
    fill(224,163,187)
    triangle(238,199,245,182,251,199)
  
    //mouth -- last two?
    stroke(0)
    strokeWeight(2)
    fill(160,0,0)
    ellipse(245,215,20,10)
  
    //hair
    stroke(90,44,7)
    fill(110,57,39)
    circle(231,109,40)
    circle(253,98,40)
    circle(203,108,40)
    circle(172,211,40)
    circle(290,106,40)
    circle(312,146,40)
    circle(195,132,40)
    circle(181,144,40)
    circle(179,173,40)
    circle(173,190,40)
    circle(176,227,40)
    circle(177,247,40)
    circle(173,265,40)
    circle(224,105,40)
    circle(273,115,40)
    circle(292,122,40)
    circle(305,142,40)
    circle(316,166,40)
    circle(321,182,40)
    circle(315,207,40)
    circle(323,236,40)
    circle(327,255,40)
    // ear muffs
    stroke(124,159,189)
    fill(159, 192, 235)
    ellipse(170,180,30,50)
    ellipse(320,180,30,50)
    noFill()
    strokeWeight(7)
    arc(244,155,148,142,PI,TWO_PI,OPEN);
  
  //body
    stroke(151,161,59)
    strokeWeight(2)
    fill(197,204,130)
    triangle(215,250,246,315,275,250)
    triangle(215,355,246,315,275,355)
    //decoration
   // fill()
   // triangle()

    //left arm
    fill(197,204,130)
    rect(207,250,10,70)
    rect(207,318,50,10)
  //
    stroke(244,223,230)
    fill(224,163,187)
    ellipse(253,315,25,15)
    ellipse(245,310,8,10)  

      //right arm
    stroke(151,161,59)
    fill(197,204,130)
    rect(273,250,10,70)
    rect(239,315,45,10)
  //mittens
    stroke(244,223,230)
    fill(224,163,187)
    ellipse(237,318,25,15)
    ellipse(245,310,8,10)

      //left leg
    stroke(124,159,189)
    fill(159, 192, 235)
    rect(215,355,17.5,150)

      //right leg
    fill(159, 192, 235)
    rect(257.5,355,17.5,150)

  // skirt
    stroke(151,161,59)
    fill(224,163,187)
    rect(213,353,64,35)
    stroke(244,223,230)
    strokeWeight(10)
    line(220,382,220,359)
    line(237,382,237,359)
    line(253,382,253,359)
    line(270,382,270,359)
    //accesories
    fill(110,57,39)
    stroke(0)
    strokeWeight(2)
    rect(211,444,26,67)
    rect(254,444,26,67)
    triangle(210,511,206,523,235,511)
    triangle(253,511,249,523,280,511)
  //
    stroke(124,159,189)
    fill(159, 192, 235)
    rect(230,236,32,15)    
    rect(250,251,15,60)
    line(250,309,250,320)
    line(255,310,255,320)
    line(260,310,260,320)
    line(265,310,265,320)

    //
    fill(255,255,255)
    ellipse(110,81,150,70)
    triangle(104,118,138,155,125,116)
    
  fill(0)
  textSize(18);
    text("I miss spring", 60,87)
  textSize(22);
  text("Matilda Pinjuv", 300,568)
  
}